/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

/**
 *
 * @author ro1
 */
public abstract class Shape {

    public abstract double getArea();  // abstract methods declared in parent without implemintation. 
public abstract double getCircuference(); 
public  abstract String getCenter();
    
}
